<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
include 'koneksi.php';


// Tambah kategori
if (isset($_POST['tambah'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama_kategori']);
    if (!empty($nama)) {
        mysqli_query($conn, "INSERT INTO kategori (nama_kategori) VALUES ('$nama')");
    }
    header("Location: kategori.php");
    exit();
}

// Hapus kategori
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM kategori WHERE id = '$id'");
    header("Location: kategori.php");
    exit();
}

// Ambil semua kategori
$result = mysqli_query($conn, "SELECT * FROM kategori ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Kategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <h2 class="text-center mb-4">Manajemen Kategori</h2>

    <!-- Form Tambah Kategori -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <form class="row g-3" method="POST">
                <div class="col-md-4">
                    <label class="form-label">Pilih Kategori Cepat</label>
                    <select class="form-select" onchange="document.getElementById('nama_kategori').value = this.value">
                        <option value="">-- Pilih Kategori --</option>
                        <option value="Alat Sekolah">Alat Sekolah</option>
                        <option value="Perlengkapan Rumah Tangga">Perlengkapan Rumah Tangga</option>
                        <option value="Elektronik">Elektronik</option>
                        <option value="Makanan">Makanan</option>
                        <option value="Minuman">Minuman</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Atau Ketik Kategori Baru</label>
                    <input type="text" name="nama_kategori" id="nama_kategori" class="form-control" placeholder="Contoh: Peralatan Kantor" required>
                </div>
                <div class="col-md-2 d-grid align-self-end">
                    <button type="submit" name="tambah" class="btn btn-success">
                        <i class="bi bi-plus-circle"></i> Tambah
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel Kategori -->
    <div class="card shadow">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-dark text-center">
                        <tr>
                            <th>No</th>
                            <th>Nama Kategori</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) : ?>
                        <tr>
                            <td class="text-center"><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($row['nama_kategori']); ?></td>
                            <td>
                            <a href='kategori.php?hapus=<?= $row["id"]; ?>' 
                             class='btn btn-danger btn-sm'
                             onclick="return confirm('Hapus kategori ini?')">
                             <i class='bi bi-trash'></i> Hapus
                             </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if (mysqli_num_rows($result) == 0): ?>
                        <tr>
                            <td colspan="3" class="text-center text-muted">Belum ada kategori ditambahkan.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
