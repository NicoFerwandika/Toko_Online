<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

// Ambil id_user dari session
$id_user = $_SESSION['id_user'] ?? 1;

// Tambah transaksi
if (isset($_POST['simpan'])) {
    $produk_id = $_POST['produk'];
    $jumlah = $_POST['jumlah'];

    // Ambil data produk
    $produk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM produk WHERE id = '$produk_id'"));
    $harga = $produk['harga'];
    $stok = $produk['stok'];
    $total = $jumlah * $harga;

    // Validasi stok
    if ($jumlah > $stok) {
        echo "<script>alert('Stok tidak mencukupi!'); window.location='transaksi.php';</script>";
        exit;
    }

    // Simpan transaksi
    mysqli_query($conn, "INSERT INTO transaksi (user_id, produk_id, jumlah, total_harga, tanggal) 
                         VALUES ('$id_user', '$produk_id', '$jumlah', '$total', NOW())");

    // Kurangi stok
    mysqli_query($conn, "UPDATE produk SET stok = stok - $jumlah WHERE id = '$produk_id'");

    echo "<script>alert('Transaksi berhasil disimpan!'); window.location='transaksi.php';</script>";
    exit;
}

// Hapus transaksi
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM transaksi WHERE id = '$id'");
    echo "<script>alert('Transaksi berhasil dihapus!'); window.location='transaksi.php';</script>";
    exit;
}

// Ambil data transaksi + join user + produk
$riwayat = mysqli_query($conn, "
    SELECT 
        t.id AS id_transaksi, 
        u.username, 
        p.nama_produk, 
        t.jumlah, 
        t.total_harga AS total 
    FROM transaksi t
    JOIN users u ON t.user_id = u.id
    JOIN produk p ON t.produk_id = p.id
    ORDER BY t.id DESC
") or die("Query Error: " . mysqli_error($conn));
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Transaksi - Toko</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-4">
    <h2 class="mb-4 text-center">Transaksi Penjualan</h2>

    <!-- Form Tambah Transaksi -->
    <form class="row g-3 mb-4" method="POST">
        <div class="col-md-5">
            <select name="produk" id="produkSelect" class="form-select" required>
                <option value="">Pilih Produk</option>
                <?php
                $produk = mysqli_query($conn, "SELECT * FROM produk WHERE stok > 0");
                while ($p = mysqli_fetch_assoc($produk)) {
                    echo "<option value='{$p['id']}' data-stok='{$p['stok']}'>
                          {$p['nama_produk']} (Stok: {$p['stok']})
                          </option>";
                }
                ?>
            </select>
        </div>
        <div class="col-md-3">
            <input type="number" name="jumlah" id="jumlahInput" class="form-control" placeholder="Jumlah" min="1" required>
        </div>
        <div class="col-md-2">
            <button type="submit" name="simpan" class="btn btn-primary w-100">Simpan</button>
        </div>
    </form>

    <!-- Riwayat Transaksi -->
    <div class="card shadow">
        <div class="card-body">
            <h5 class="card-title">Riwayat Transaksi</h5>
            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Produk</th>
                            <th>Jumlah</th>
                            <th>Total (Rp)</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($riwayat)) : ?>
                        <tr>
                            <td class="text-center"><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['username']) ?></td>
                            <td><?= htmlspecialchars($row['nama_produk']) ?></td>
                            <td class="text-center"><?= $row['jumlah'] ?></td>
                            <td>Rp<?= number_format($row['total'], 0, ',', '.') ?></td>
                            <td class="text-center">
                                <a href="transaksi.php?hapus=<?= $row['id_transaksi'] ?>" 
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Yakin ingin menghapus transaksi ini?')">
                                   Hapus
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if (mysqli_num_rows($riwayat) == 0): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted">Belum ada transaksi.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript Validasi -->
<script>
document.getElementById('produkSelect').addEventListener('change', function () {
    const selectedOption = this.options[this.selectedIndex];
    const stok = selectedOption.getAttribute('data-stok');
    const jumlahInput = document.getElementById('jumlahInput');
    
    jumlahInput.max = stok;
    jumlahInput.value = "";
    jumlahInput.placeholder = "Max: " + stok;
});
</script>

</body>
</html>
