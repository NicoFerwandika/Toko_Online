<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Tampilkan semua error (debugging di hosting)
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'koneksi.php';

// Tambah produk
if (isset($_POST['tambah'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $harga = mysqli_real_escape_string($conn, $_POST['harga']);
    $stok = mysqli_real_escape_string($conn, $_POST['stok']);
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);

    // Upload gambar
    $namaFile = $_FILES['gambar']['name'];
    $tmpName = $_FILES['gambar']['tmp_name'];
    $uploadDir = '../assets/img/';

    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $targetPath = $uploadDir . basename($namaFile);

    if (!move_uploaded_file($tmpName, $targetPath)) {
        die("Gagal upload gambar.");
    }

    // Query insert
    $sql = "INSERT INTO produk (nama_produk, harga, stok, kategori_id, gambar)
            VALUES ('$nama', '$harga', '$stok', '$kategori', '$namaFile')";
    if (!mysqli_query($conn, $sql)) {
        die("Query Error Tambah Produk: " . mysqli_error($conn));
    }
    header("Location: produk.php");
    exit();
}

// Hapus produk
if (isset($_GET['hapus'])) {
    $id = mysqli_real_escape_string($conn, $_GET['hapus']);
    $hapus = mysqli_query($conn, "DELETE FROM produk WHERE id = '$id'");
    if (!$hapus) {
        die("Gagal menghapus: " . mysqli_error($conn));
    }
    header("Location: produk.php");
    exit();
}

// Cari produk
$search = isset($_GET['cari']) ? mysqli_real_escape_string($conn, $_GET['cari']) : '';
$query = "SELECT produk.*, kategori.nama_kategori 
          FROM produk 
          JOIN kategori ON produk.kategori_id = kategori.id 
          WHERE produk.nama_produk LIKE '%$search%' 
          ORDER BY produk.id DESC";

$result = mysqli_query($conn, $query);
if (!$result) {
    die("Query Error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <h2 class="text-center mb-4">Manajemen Produk</h2>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form class="row g-3" method="GET">
                <div class="col-md-10">
                    <input type="text" name="cari" class="form-control" placeholder="Cari produk..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2 d-grid">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search"></i> Cari
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form class="row g-3" method="POST" enctype="multipart/form-data">
                <div class="col-md-2">
                    <input type="text" name="nama" class="form-control" placeholder="Nama Produk" required>
                </div>
                <div class="col-md-2">
                    <input type="number" name="harga" class="form-control" placeholder="Harga" required>
                </div>
                <div class="col-md-2">
                    <input type="number" name="stok" class="form-control" placeholder="Stok" required>
                </div>
                <div class="col-md-3">
                    <select name="kategori" class="form-select" required>
                        <option value="">Pilih Kategori</option>
                        <?php
                        $kat = mysqli_query($conn, "SELECT * FROM kategori");
                        while ($k = mysqli_fetch_assoc($kat)) {
                            echo "<option value='{$k['id']}'>{$k['nama_kategori']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <input type="file" name="gambar" class="form-control" accept="image/*" required>
                </div>
                <div class="col-md-1 d-grid">
                    <button type="submit" name="tambah" class="btn btn-success">
                        <i class="bi bi-plus-circle"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-dark text-center">
                        <tr>
                            <th>No</th>
                            <th>Gambar</th>
                            <th>Nama</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Kategori</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) : ?>
                        <tr>
                            <td class="text-center"><?php echo $no++; ?></td>
                            <td class="text-center">
                                <img src="../assets/img/<?php echo htmlspecialchars($row['gambar']); ?>" style="width: 60px; height: 60px; object-fit: cover;">
                            </td>
                            <td><?php echo htmlspecialchars($row['nama_produk']); ?></td>
                            <td>Rp<?php echo number_format($row['harga'], 0, ',', '.'); ?></td>
                            <td><?php echo $row['stok']; ?></td>
                            <td><?php echo $row['nama_kategori']; ?></td>
                            <td class="text-center">
                                <a href="produk.php?hapus=<?php echo $row['id']; ?>" 
                                   class="btn btn-danger btn-sm" 
                                   onclick="return confirm('Yakin ingin menghapus produk ini?')">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if (mysqli_num_rows($result) == 0): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted">Tidak ada produk ditemukan.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
