<?php
$host = "localhost";
$user = "ribg3268_unsada";
$pass = "Sjtalj234567";
$db   = "ribg3268_db_store";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
