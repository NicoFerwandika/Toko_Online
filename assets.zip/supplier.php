<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

// Tambah Supplier
if (isset($_POST['tambah'])) {
    $nama   = mysqli_real_escape_string($conn, $_POST['nama_supplier']);
    $kontak = mysqli_real_escape_string($conn, $_POST['kontak']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);

    mysqli_query($conn, "INSERT INTO supplier (nama_supplier, kontak, alamat) VALUES ('$nama', '$kontak', '$alamat')");
    header("Location: supplier.php");
    exit();
}

// Hapus Supplier
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM supplier WHERE id = '$id'");
    header("Location: supplier.php");
    exit();
}

// Ambil data supplier
$result = mysqli_query($conn, "SELECT * FROM supplier ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Supplier</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <h2 class="mb-4 text-center">Manajemen Supplier</h2>

    <!-- Form Tambah Supplier -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <form class="row g-3" method="POST">
                <div class="col-md-4">
                    <input type="text" name="nama_supplier" class="form-control" placeholder="Masukkan Nama Supplier" required>
                </div>
                <div class="col-md-3">
                    <input type="text" name="kontak" class="form-control" placeholder="Nomor Kontak" required>
                </div>
                <div class="col-md-3">
                    <input type="text" name="alamat" class="form-control" placeholder="Alamat Lengkap" required>
                </div>
                <div class="col-md-2 d-grid">
                    <button type="submit" name="tambah" class="btn btn-success">
                        <i class="bi bi-plus-circle"></i> Tambah
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel Data Supplier -->
    <div class="card shadow">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-dark text-center">
                        <tr>
                            <th>No</th>
                            <th>Nama Supplier</th>
                            <th>Kontak</th>
                            <th>Alamat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) : ?>
                        <tr>
                            <td class="text-center"><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($row['nama_supplier']); ?></td>
                            <td><?php echo htmlspecialchars($row['kontak']); ?></td>
                            <td><?php echo htmlspecialchars($row['alamat']); ?></td>
                            <td class="text-center">
                                <a href="supplier.php?hapus=<?php echo $row['id']; ?>" 
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Hapus supplier ini?')">
                                   <i class="bi bi-trash"></i> Hapus
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if (mysqli_num_rows($result) == 0): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">Belum ada data supplier.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
