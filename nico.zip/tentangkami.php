<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tentang Kami - Toko Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f9f9f9;
            font-family: 'Segoe UI', sans-serif;
        }

        .section {
            padding: 60px 0;
        }

        .section-title {
            color: #0d6efd;
            font-weight: 700;
            text-align: center;
            margin-bottom: 40px;
        }

        .contact-info i {
            font-size: 1.3rem;
            color: #0d6efd;
            margin-right: 10px;
        }

        .footer {
            background-color: #0d6efd;
            color: #fff;
            padding: 20px;
            margin-top: 60px;
            text-align: center;
        }

        .card {
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }

        .card h5 {
            color: #0d6efd;
        }
    </style>
</head>
<body>

<div class="container section">
    <h2 class="section-title">Tentang Kami</h2>
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card p-4">
                <p>
                    Selamat datang di <strong>Toko Online</strong>, tempat terbaik untuk memenuhi kebutuhan harian Anda! Kami menyediakan berbagai produk seperti alat sekolah, elektronik, makanan, dan banyak lagi dengan harga terjangkau dan pelayanan yang ramah.
                </p>
                <p>
                    Dengan dukungan tim profesional dan sistem manajemen toko yang modern, kami selalu berkomitmen untuk memberikan pengalaman belanja online yang cepat, aman, dan memuaskan.
                </p>
                <p>
                    Terima kasih telah mempercayai kami sebagai solusi belanja Anda!
                </p>
            </div>
        </div>
    </div>
</div>

<div class="container section">
    <h2 class="section-title">Hubungi Kami</h2>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card p-4">
                <div class="contact-info mb-3">
                    <p><i class="bi bi-envelope-fill"></i> Email: support@tokoonline.com</p>
                    <p><i class="bi bi-telephone-fill"></i> Telepon: (021) 123-4567</p>
                    <p><i class="bi bi-whatsapp"></i> WhatsApp: +62 812 3456 7890</p>
                    <p><i class="bi bi-geo-alt-fill"></i> Alamat: Jl. Belanja No. 10, Jakarta</p>
                </div>
                <div class="mt-4">
                    <p>Anda juga dapat mengisi formulir di bawah ini:</p>
                    <form method="POST" action="#">
                        <div class="mb-3">
                            <input type="text" name="nama" class="form-control" placeholder="Nama Anda" required>
                        </div>
                        <div class="mb-3">
                            <input type="email" name="email" class="form-control" placeholder="Email Anda" required>
                        </div>
                        <div class="mb-3">
                            <textarea name="pesan" class="form-control" rows="4" placeholder="Pesan Anda..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Kirim Pesan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="footer">
    &copy; <?= date('Y') ?> Toko Online. Semua Hak Dilindungi.
</div>

<!-- Bootstrap JS & Icons -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</body>
</html>
