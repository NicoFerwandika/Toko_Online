<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>FAQ - Toko Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f9f9f9;
            font-family: 'Segoe UI', sans-serif;
        }

        .section {
            padding: 60px 0;
        }

        .section-title {
            color: #0d6efd;
            font-weight: bold;
            text-align: center;
            margin-bottom: 40px;
        }

        .accordion-button:not(.collapsed) {
            background-color: #0d6efd;
            color: white;
        }

        .accordion-button::after {
            color: white;
        }

        .accordion-body {
            background-color: #fff;
        }

        .footer {
            background-color: #0d6efd;
            color: #fff;
            padding: 20px;
            text-align: center;
            margin-top: 60px;
        }
    </style>
</head>
<body>

<div class="container section">
    <h2 class="section-title">Pertanyaan Umum (FAQ)</h2>

    <div class="accordion" id="faqAccordion">
        <?php
        $faqs = [
            ['Apa itu Toko Online?', 'Toko Online adalah platform e-commerce yang menyediakan berbagai kebutuhan seperti alat tulis, makanan, minuman, hingga elektronik.'],
            ['Bagaimana cara melakukan pemesanan?', 'Kamu bisa memilih produk dari halaman Produk, lalu lakukan transaksi pada menu Transaksi.'],
            ['Apakah saya harus membuat akun?', 'Ya, untuk memesan produk, kamu harus login terlebih dahulu sebagai pengguna yang terdaftar.'],
            ['Apa saja metode pembayaran yang tersedia?', 'Saat ini kami hanya melayani pembayaran tunai saat pengambilan barang. Ke depannya akan tersedia metode digital.'],
            ['Apakah produk yang saya pesan bisa dikembalikan?', 'Pengembalian barang hanya dapat dilakukan jika terdapat kerusakan pada produk saat diterima.'],
            ['Bagaimana cara menghubungi admin?', 'Kamu bisa ke halaman Tentang Kami untuk melihat kontak WhatsApp, Email, atau isi form Hubungi Kami.'],
            ['Apakah stok produk selalu diperbarui?', 'Ya, stok produk akan otomatis berkurang setiap terjadi transaksi, dan dapat dicek di halaman Produk.']
        ];

        foreach ($faqs as $index => $faq) {
            $id = "faq" . $index;
            echo "
            <div class='accordion-item'>
                <h2 class='accordion-header' id='heading{$id}'>
                    <button class='accordion-button ".($index !== 0 ? 'collapsed' : '')."' type='button' data-bs-toggle='collapse' data-bs-target='#collapse{$id}' aria-expanded='".($index === 0 ? 'true' : 'false')."' aria-controls='collapse{$id}'>
                        {$faq[0]}
                    </button>
                </h2>
                <div id='collapse{$id}' class='accordion-collapse collapse ".($index === 0 ? 'show' : '')."' aria-labelledby='heading{$id}' data-bs-parent='#faqAccordion'>
                    <div class='accordion-body'>{$faq[1]}</div>
                </div>
            </div>";
        }
        ?>
    </div>
</div>

<div class="footer">
    &copy; <?= date('Y') ?> Toko Online. Semua Hak Dilindungi.
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
