<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Toko</title>
    <!-- Bootstrap 5.3 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
         background: url('logo.jpg') no-repeat center center fixed;
         background-size: cover;
         background-repeat: no-repeat;
         background-attachment: fixed;
         background-position: center;
          font-family: 'Segoe UI', sans-serif;
          backdrop-filter: brightness(95%);
}


        .navbar {
            background-color: #0d6efd !important;
        }

        .navbar .nav-link,
        .navbar-brand {
            color: #fff !important;
            font-weight: 500;
        }

        .navbar .nav-link:hover {
            color: #dce5ff !important;
        }

        .welcome-text {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .card {
            border-radius: 15px;
            transition: transform 0.3s ease;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-title {
            font-size: 1.1rem;
            font-weight: 600;
        }

        .btn-sm {
            border-radius: 20px;
            font-size: 0.875rem;
        }

        .icon-menu {
            font-size: 2rem;
        }

        /* Gradasi warna dan shadow untuk teks selamat datang */
        .gradient-text {
            background: linear-gradient(90deg, #0d6efd, #6610f2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
            font-size: 2.3rem;
        }

        footer {
            margin-top: 80px;
            padding: 20px;
            background-color: #0d6efd;
            color: #fff;
            text-align: center;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg shadow-sm">
    <div class="container">
        <a class="navbar-brand text-white" href="index.php">Toko Online</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon bg-light rounded"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 d-flex flex-wrap gap-3 px-3">
                <li class="nav-item"><a class="nav-link text-white" href="index.php">Beranda</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="produk.php">Produk</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="kategori.php">Kategori</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="transaksi.php">Transaksi</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="tentangkami.php">Tentang Kami</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="faq.php">FAQ</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="supplier.php">Supplier</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="user.php">User</a></li>
            </ul>
            <span class="navbar-text text-white me-3">
                Halo, <strong><?= $_SESSION['username']; ?></strong> (<?= $_SESSION['role']; ?>)
            </span>
            <a href="logout.php" class="btn btn-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<!-- Konten Utama -->
<div class="container py-5">
    <div class="text-center mb-5 welcome-text">
        <h2 class="gradient-text">Selamat Datang di Toko Online Kami !!</h2>
        <p class="text-muted">Halo, <strong><?= $_SESSION['username']; ?></strong>! Anda login sebagai <strong><?= $_SESSION['role']; ?></strong>.</p>
    </div>

    <div class="row g-4">
        <?php
        $menus = [
    ['Produk', 'produk.php', 'primary', 'bi-box'],
    ['Kategori', 'kategori.php', 'success', 'bi-tags'],
    ['Transaksi', 'transaksi.php', 'info', 'bi-cash-coin'],
    ['Tentang Kami', 'tentangkami.php', 'dark', 'bi-info-circle'],
    ['FAQ', 'faq.php', 'warning', 'bi-question-circle'],
    ['Supplier', 'supplier.php', 'secondary', 'bi-truck'],
    ['User', 'user.php', 'danger', 'bi-person-circle'],
    ['Logout', 'logout.php', 'outline-dark', 'bi-box-arrow-right'] 
];


        foreach ($menus as $menu) {
            $btnStyle = $menu[0] === 'Logout' ? 'btn-'.$menu[2] : 'btn-outline-'.$menu[2];
            echo "
            <div class='col-md-3'>
                <div class='card h-100'>
                    <div class='card-body text-center'>
                        <i class='bi {$menu[3]} icon-menu text-{$menu[2]} mb-2'></i>
                        <h5 class='card-title text-{$menu[2]}'>{$menu[0]}</h5>
                        <a href='{$menu[1]}' class='btn $btnStyle btn-sm mt-2'>"
                            . ($menu[0] === 'Logout' ? 'Keluar' : 'Kelola '.$menu[0]) .
                        "</a>
                    </div>
                </div>
            </div>";
        }
        ?>
    </div>
</div>

<!-- Footer -->
<footer>
    &copy; <?= date('Y') ?> Sistem Toko. Hak Cipta Dilindungi.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
